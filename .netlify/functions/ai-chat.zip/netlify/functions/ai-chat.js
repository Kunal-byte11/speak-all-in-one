var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/ai-chat.ts
var ai_chat_exports = {};
__export(ai_chat_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(ai_chat_exports);
var import_generative_ai = require("@google/generative-ai");
var genAI = new import_generative_ai.GoogleGenerativeAI(process.env.GOOGLE_GENAI_API_KEY);
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    const { userMessage, conversationHistory } = JSON.parse(event.body || "{}");
    if (!userMessage) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "userMessage is required" })
      };
    }
    console.log("Received chat request:", { userMessage, historyLength: conversationHistory?.length || 0 });
    let contextPrompt = "";
    if (conversationHistory && conversationHistory.length > 0) {
      contextPrompt = "\n\nPrevious conversation:\n";
      conversationHistory.slice(-5).forEach((msg) => {
        contextPrompt += `${msg.role === "user" ? "User" : "Counselor"}: ${msg.content}
`;
      });
    }
    const therapeuticPrompt = `You are a professional, empathetic AI counselor trained in evidence-based therapeutic approaches including CBT, DBT, and person-centered therapy. Your role is to provide supportive, non-judgmental guidance while maintaining professional boundaries.

THERAPEUTIC GUIDELINES:
1. **Active Listening & Empathy First**: Always acknowledge and validate the user's feelings. Use reflective listening. Normalize their experience.
2. **Collaborative Stance**: Use "we" language. Partner with the user. Give them choices on where to take the conversation.
3. **Pacing**: Don't rush to solutions. First, listen and explore. However, if the user directly asks for suggestions or "what to do," provide a few clear, actionable strategies.
4. **Strength-Based**: Identify and build upon the user's existing strengths. Reframe help-seeking as a strength.
5. **Safety Priority**: Assess for risk indicators while maintaining therapeutic rapport.

RESPONSE STRUCTURE:
1. **Emotional Validation**: Start with a strong acknowledgment of their feelings and normalize the experience.
2. **Gentle Exploration**: Use gentle, open-ended questions to understand more.
3. **Offer Support**: Provide practical coping strategies when appropriate.
4. **Empowering Closing**: End with a hopeful and encouraging statement.

RISK ASSESSMENT:
- Screen for suicidal ideation, self-harm, or harm to others.
- Note expressions of hopelessness, worthlessness, or isolation.

Remember: You're creating a safe, supportive space where the user feels heard, understood, and empowered. Be conversational and avoid overly clinical language.

${contextPrompt}

Current user message: ${userMessage}

Please respond as a caring counselor would, keeping your response concise but meaningful (2-4 sentences).`;
    console.log("Calling Google AI...");
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    const result = await model.generateContent(therapeuticPrompt);
    const aiResponse = result.response.text();
    const emotionalTone = assessEmotionalTone(userMessage);
    const riskLevel = assessRiskLevel(userMessage);
    const response = {
      response: aiResponse,
      emotionalTone,
      riskIndicators: {
        level: riskLevel,
        flags: riskLevel !== "none" ? ["Requires attention"] : []
      }
    };
    console.log("AI response generated successfully");
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(response)
    };
  } catch (error) {
    console.error("AI chat error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to generate response",
        details: error.message
      })
    };
  }
};
function assessEmotionalTone(message) {
  const lowerMessage = message.toLowerCase();
  if (lowerMessage.includes("stressed") || lowerMessage.includes("anxious") || lowerMessage.includes("worried")) {
    return "supportive";
  } else if (lowerMessage.includes("sad") || lowerMessage.includes("depressed") || lowerMessage.includes("down")) {
    return "empathetic";
  } else if (lowerMessage.includes("angry") || lowerMessage.includes("frustrated")) {
    return "validating";
  } else if (lowerMessage.includes("help") || lowerMessage.includes("advice")) {
    return "exploratory";
  }
  return "encouraging";
}
function assessRiskLevel(message) {
  const lowerMessage = message.toLowerCase();
  if (lowerMessage.includes("kill") || lowerMessage.includes("suicide") || lowerMessage.includes("end it all") || lowerMessage.includes("better off dead")) {
    return "critical";
  } else if (lowerMessage.includes("hurt myself") || lowerMessage.includes("self harm") || lowerMessage.includes("cut myself")) {
    return "high";
  } else if (lowerMessage.includes("hopeless") || lowerMessage.includes("worthless") || lowerMessage.includes("no point")) {
    return "moderate";
  } else if (lowerMessage.includes("stressed") || lowerMessage.includes("overwhelmed") || lowerMessage.includes("can't cope")) {
    return "low";
  }
  return "none";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
